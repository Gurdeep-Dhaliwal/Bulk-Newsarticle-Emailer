import smtplib
from email.message import EmailMessage
import xlrd                              # these two import are non standard libary
from newsapi import newsapi_client       #
import pandas as pd

SENDER_EMAIL = "dhaliwal.gurdeep50@gmail.com"
SENDER_PASSWORD = "Woodlane50"

news = "https://www.msn.com/en-gb/news/spotlight/mi6-the-coup-in-iran-that-changed-the-middle-east-and-the-cover-up/ar-BB17t48c"


#  This code is used from a tutorial From Newsapi.org

def top_news():
    my_api_key = '990ff1fef333470dbb0b501ecb478805'
    newsapi = newsapi_client.NewsApiClient(api_key=my_api_key)
    data = newsapi.get_top_headlines(language='en',
                                     q='coronavirus',
                                     page_size=20)
    articles = data['articles']
    for x, y in enumerate(articles):
        return f'{x}  {y["title"]}'


def subscribers():
    SubsFileLocation = r'C:\Users\Gurdeep\Documents/Email.xlsx'
    wb = xlrd.open_workbook(SubsFileLocation)
    sheet = wb.sheet_by_index(0)
    sheet.cell_value(0, 0)
    for i in range(sheet.nrows):
        return sheet.cell_value(i, 0)


Subscribers = ['dhaliwal.gurdeep50@gmail.com, woodlane50@gmail.com, no10creaper@gmail.com']
subs = ', '.join(Subscribers)


def send_news(to_email):
    msg = EmailMessage()
    msg['From'] = SENDER_EMAIL
    msg['To'] = to_email
    msg['Subject'] = 'Dhaliwal News'
    msg.set_content(news)
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
        smtp.login(SENDER_EMAIL, SENDER_PASSWORD)
        smtp.send_message(msg)


# html_message = open('demo.html').read()
# msg.add_alternative(html_message, subtype='html')

send_news(subscribers())
